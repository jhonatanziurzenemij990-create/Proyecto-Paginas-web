import { useState } from 'react';
import { Search, ChevronLeft, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Home() {
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState('');

  const pages = [
    {
      id: 1,
      title: 'Nike: Identidad Tipográfica',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663733075529/EeNuPb8kVX6QAGP968m89A/page-1.png',
      description: 'Análisis de la identidad tipográfica de Nike basada en Futura ND Nike 365.',
    },
    {
      id: 2,
      title: 'Composición Visual - Naturaleza',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663733075529/EeNuPb8kVX6QAGP968m89A/page-2.png',
      description: 'Proyecto de composición visual con fotografías de naturaleza y formas geométricas.',
    },
    {
      id: 3,
      title: 'Mi Primera Página Web & Horario de Clases',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663733075529/EeNuPb8kVX6QAGP968m89A/page-3.png',
      description: 'Página web personal con estructura HTML y tabla de horario de clases.',
    },
    {
      id: 4,
      title: 'Pokédex Preparatoria',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663733075529/EeNuPb8kVX6QAGP968m89A/page-4.png',
      description: 'Galería interactiva de Pokémon con búsqueda en tiempo real.',
    },
  ];

  const nextPage = () => {
    setCurrentPage((prev) => (prev === pages.length ? 1 : prev + 1));
  };

  const prevPage = () => {
    setCurrentPage((prev) => (prev === 1 ? pages.length : prev - 1));
  };

  const currentPageData = pages[currentPage - 1];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 via-white to-gray-100">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-200">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold text-black">Mis Prácticas</h1>
              <p className="text-sm text-gray-600">Diseño Digital y Páginas Web</p>
            </div>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-black text-white flex items-center justify-center font-bold">
                U
              </div>
            </div>
          </div>

          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <input
              type="text"
              placeholder="Buscar proyecto..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-3 rounded-full bg-gray-100 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-black focus:border-transparent transition-all"
            />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-12">
        {/* Featured Project Card */}
        <section className="mb-12">
          <div className="bg-white rounded-3xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow duration-300 border border-gray-200">
            <div className="relative">
              {/* Image Container */}
              <div className="relative w-full max-h-96 overflow-hidden bg-gray-100">
                <img
                  src={currentPageData.image}
                  alt={currentPageData.title}
                  className="w-full h-full object-contain"
                />
              </div>

              {/* Navigation Buttons */}
              <div className="absolute inset-0 flex items-center justify-between px-6 pointer-events-none">
                <button
                  onClick={prevPage}
                  className="pointer-events-auto p-3 rounded-full bg-black/70 hover:bg-black text-white transition-all duration-200 transform hover:scale-110"
                >
                  <ChevronLeft className="w-6 h-6" />
                </button>
                <button
                  onClick={nextPage}
                  className="pointer-events-auto p-3 rounded-full bg-black/70 hover:bg-black text-white transition-all duration-200 transform hover:scale-110"
                >
                  <ChevronRight className="w-6 h-6" />
                </button>
              </div>

              {/* Page Indicator */}
              <div className="absolute bottom-4 right-4 bg-black/80 text-white px-4 py-2 rounded-full text-sm font-semibold">
                {currentPage} / {pages.length}
              </div>
            </div>

            {/* Content Section */}
            <div className="p-8">
              <div className="inline-block mb-4 bg-black text-white px-4 py-2 rounded-full text-sm font-semibold">
                Proyecto {currentPage}
              </div>
              <h2 className="text-3xl font-bold text-black mb-3">{currentPageData.title}</h2>
              <p className="text-gray-700 text-lg leading-relaxed mb-6">
                {currentPageData.description}
              </p>
              <div className="flex gap-4">
                <Button className="bg-black text-white hover:bg-gray-800 rounded-full px-8 py-6 font-semibold">
                  Ver Detalles
                </Button>
                <Button
                  variant="outline"
                  className="border-black text-black hover:bg-gray-100 rounded-full px-8 py-6 font-semibold"
                >
                  Compartir
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Thumbnails Navigation */}
        <section className="mb-12">
          <h3 className="text-2xl font-bold text-black mb-6">Todos los Proyectos</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {pages.map((page, index) => (
              <button
                key={page.id}
                onClick={() => setCurrentPage(page.id)}
                className={`relative rounded-2xl overflow-hidden transition-all duration-300 transform hover:scale-105 ${
                  currentPage === page.id
                    ? 'ring-4 ring-black shadow-lg'
                    : 'hover:shadow-lg opacity-70 hover:opacity-100'
                }`}
              >
                <img
                  src={page.image}
                  alt={page.title}
                  className="w-full h-32 object-cover"
                />
                <div className="absolute inset-0 bg-black/0 hover:bg-black/20 transition-colors duration-300" />
                <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3">
                  <p className="text-white text-xs font-semibold truncate">{page.title}</p>
                </div>
              </button>
            ))}
          </div>
        </section>

        {/* Info Section */}
        <section className="bg-black text-white rounded-3xl p-12 mb-12">
          <h3 className="text-2xl font-bold mb-4">Sobre Este Portafolio</h3>
          <p className="text-gray-300 text-lg leading-relaxed mb-6">
            Este portafolio contiene mis proyectos de diseño digital y desarrollo web del primer y segundo parcial. 
            Incluye análisis tipográfico, composición visual, desarrollo web con HTML y CSS, y proyectos interactivos.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white/10 rounded-xl p-6 border border-white/20">
              <h4 className="font-bold text-lg mb-2">Primer Parcial</h4>
              <p className="text-gray-300 text-sm">Proyectos de diseño digital y análisis tipográfico</p>
            </div>
            <div className="bg-white/10 rounded-xl p-6 border border-white/20">
              <h4 className="font-bold text-lg mb-2">Segundo Parcial</h4>
              <p className="text-gray-300 text-sm">Desarrollo web, páginas interactivas y aplicaciones</p>
            </div>
            <div className="bg-white/10 rounded-xl p-6 border border-white/20">
              <h4 className="font-bold text-lg mb-2">Habilidades</h4>
              <p className="text-gray-300 text-sm">HTML, CSS, Diseño, Tipografía, Composición</p>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-black text-white border-t border-gray-800">
        <div className="container mx-auto px-4 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div>
              <h4 className="font-bold text-lg mb-4">Mis Prácticas</h4>
              <p className="text-gray-400 text-sm">
                Portafolio de diseño digital y desarrollo web del primer y segundo parcial.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-lg mb-4">Navegación</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Inicio</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Proyectos</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contacto</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-lg mb-4">Información</h4>
              <p className="text-gray-400 text-sm">
                Proyecto Final - Segundo Parcial
              </p>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-gray-400 text-sm">
            <p>&copy; 2026 Mis Prácticas de Diseño. Todos los derechos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
